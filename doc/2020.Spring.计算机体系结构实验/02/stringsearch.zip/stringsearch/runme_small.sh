#!/bin/sh
search_small > output_small.txt
